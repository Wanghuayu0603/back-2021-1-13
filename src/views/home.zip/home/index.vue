<template>
  <div class="container">
    <el-form
      :model="ruleForm"
      ref="ruleForm"
      label-width="100px"
      class="demo-ruleForm"
    >
      <el-form-item label="活动性质" prop="type">
        <el-checkbox-group @change="triggerChange" v-model="ruleForm.type">
          <el-checkbox
            v-for="(item, i) in checkArr"
            :label="item"
            :key="i"
            name="type"
          ></el-checkbox>
        </el-checkbox-group>
      </el-form-item>
    </el-form>
    <el-checkbox
      v-model="allChecked"
      label="全选"
      name="type"
      @change="triggerAll"
    ></el-checkbox>
    <!-- <img src="../../assets/welcome.png" alt="" /> -->
  </div>
</template>

<script>
export default {
  name: "Home",
  data() {
    return {
      ruleForm: {
        type: [],
      },
      checkArr: ["美食", "地推活动", "线下主题活动", "单纯品牌曝光"],
      allChecked: false,
    };
  },
  methods: {
    triggerChange(isChecked) {
      isChecked.length == this.checkArr.length
        ? (this.allChecked = true)
        : (this.allChecked = false);
      console.log(isChecked);
    },
    triggerAll() {
      this.allChecked
        ? (this.ruleForm.type = this.checkArr)
        : (this.ruleForm.type = []);

      console.log(this.allChecked);
    },
  },
};
</script>

<style lang="scss" scoped>
.container {
  img {
    width: 100%;
    height: 100%;
    position: absolute;
    left: 0%;
    top: 0;
  }
}
</style>
